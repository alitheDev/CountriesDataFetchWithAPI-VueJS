<template>
  <div>
    <h2>Country Information</h2>
    <div v-if="countryData">
      <p>Name: {{ countryData.name.common }}</p>
      <p>Capital: {{ countryData.capital }}</p>
      <p>Population: {{ countryData.population }}</p>
      <!-- Display other desired information -->
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      countryData: null,
    };
  },
  methods: {
    async fetchCountryData() {
      const name = 'COUNTRY_NAME'; // Replace with the desired country name
      const url = `https://restcountries.com/v3.1/name/${name}`;
      try {
        const response = await axios.get(url);
        this.countryData = response.data[0];
      } catch (error) {
        console.error('Error retrieving country data:', error);
      }
    },
  },
  mounted() {
    this.fetchCountryData();
  },
};
</script>

<style scoped>
/* Your component-specific styles */
</style>