<template>
  <div>
    <h2>Country Information</h2>
    <div class="country-container">
      <div v-for="country in countries" :key="country.name.common" class="country-card">
        <h3>{{ country.name.common }}</h3>
        <p><span class="label">Capital:</span> {{ country.capital }}</p>
        <p><span class="label">Population:</span> {{ country.population }}</p>
        <!-- Display other desired information -->
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      countries: [],
    };
  },
  methods: {
    async fetchCountryData(endpoint) {
      try {
        const response = await axios.get(endpoint);
        this.countries = response.data;
      } catch (error) {
        console.error('Error retrieving country data:', error);
      }
    },
  },
  mounted() {
    this.fetchCountryData('https://restcountries.com/v3.1/all');
    // Replace 'Asia' with the desired region or use the other endpoints mentioned below:
    // this.fetchCountryData('https://restcountries.com/v3.1/currency/pkr');
    // this.fetchCountryData('https://restcountries.com/v3.1/capital/Isl');

  },
};
</script>

<style scoped>
.country-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  grid-gap: 20px;
  
}

.country-card {
  padding: 20px;
  border: 1px solid #e4e4e4;
  border-radius: 4px;
  background-color: #f8f8f8;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  border: 1px solid black;
}

.country-card h3 {
  margin: 0;
  font-size: 20px;
  font-weight: bold;
  color: #333;
}

.label {
  font-weight: bold;
  color: #666;
}

p {
  margin: 10px 0;
}
</style>
